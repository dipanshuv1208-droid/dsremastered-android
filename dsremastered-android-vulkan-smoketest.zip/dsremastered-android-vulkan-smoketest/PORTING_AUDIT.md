# Audit of the supplied Lordran Native source ZIP

## Findings

- The repository README describes the project as a native Apple-platform port of Dark Souls: Remastered for Nintendo Switch title ID `01004AB00A260000`.
- The existing game's ARM64 code is rewritten for Apple hardware; the project hosts Horizon services and implements Nintendo's NVN graphics interface on Metal.
- The host layer is in `dm/host/`.
- The NVN/Metal implementation is in `dm/gfx/nvn/`, including Objective-C/Metal code.
- The iOS app and touch controls are in `dm/ios/`.
- The supplied ZIP has no Android Gradle app module, no Android manifest, and no Android Vulkan backend.
- The README's supported build paths require Apple Silicon/macOS with Xcode or an experimental Windows shell route. Neither is an Android-native build route.

## Android work that would be required

1. Create an Android app host and lifecycle/input/audio integration.
2. Add an Android NDK/CMake build and audit the existing C/C++ code for Apple-only APIs.
3. Implement or port an NVN-compatible graphics backend to Vulkan. The current Metal implementation cannot be compiled for Android as-is.
4. Port or replace Apple-specific host services and app/UI integration.
5. Validate shader translation, memory mapping, synchronization, video/audio, touch controls, saves, and lifecycle.
6. Build and test on a physical Android device, then profile performance. An APK build alone does not prove the game runs or reaches 20–30 FPS.

## First milestone in the companion project

`Vulkan Device Check` is a separate minimal native Android APK project. It tests native C++ loading, Vulkan instance creation, and physical-device enumeration. It does not draw a frame, run the game, or prove that the full port is feasible. The project includes a GitHub Actions workflow to build a debug APK on a hosted runner.

No game data, keys, or copyrighted game assets are included in the test project.
