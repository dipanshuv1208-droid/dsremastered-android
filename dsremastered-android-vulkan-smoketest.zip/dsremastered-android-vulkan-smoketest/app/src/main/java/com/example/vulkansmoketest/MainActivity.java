package com.example.vulkansmoketest;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Typeface;
import android.view.Gravity;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {
    static {
        System.loadLibrary("vulkan_probe");
    }

    private native String getVulkanDeviceReport();

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);

        TextView text = new TextView(this);
        text.setText("Dark Souls Remastered — Android Port Prep\n\n"
                + "Milestone 1: native Android + Vulkan device check\n\n"
                + getVulkanDeviceReport()
                + "\n\nThis test does NOT run the game. It checks whether an Android "
                + "native app can create a Vulkan instance and see the GPU.");
        text.setTextSize(16);
        text.setTypeface(Typeface.MONOSPACE);
        text.setPadding(24, 24, 24, 24);
        text.setGravity(Gravity.START);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(text);
        setContentView(scroll);
    }
}
