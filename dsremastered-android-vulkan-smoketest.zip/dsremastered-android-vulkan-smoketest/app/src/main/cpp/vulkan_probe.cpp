#include <jni.h>
#include <vulkan/vulkan.h>
#include <sstream>
#include <string>
#include <vector>

extern "C" JNIEXPORT jstring JNICALL
Java_com_example_vulkansmoketest_MainActivity_getVulkanDeviceReport(
        JNIEnv* env, jobject /* thiz */) {
    std::ostringstream out;
    out << "Native library loaded successfully.\n";

    VkApplicationInfo appInfo{};
    appInfo.sType = VK_STRUCTURE_TYPE_APPLICATION_INFO;
    appInfo.pApplicationName = "DS Remastered Android Port Prep";
    appInfo.applicationVersion = VK_MAKE_VERSION(0, 1, 0);
    appInfo.pEngineName = "Vulkan Probe";
    appInfo.engineVersion = VK_MAKE_VERSION(0, 1, 0);
    appInfo.apiVersion = VK_API_VERSION_1_0;

    VkInstanceCreateInfo createInfo{};
    createInfo.sType = VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO;
    createInfo.pApplicationInfo = &appInfo;

    VkInstance instance = VK_NULL_HANDLE;
    VkResult result = vkCreateInstance(&createInfo, nullptr, &instance);
    if (result != VK_SUCCESS) {
        out << "Vulkan instance creation FAILED. VkResult=" << result
            << "\nThis does not prove the full game is incompatible.";
        return env->NewStringUTF(out.str().c_str());
    }

    uint32_t count = 0;
    result = vkEnumeratePhysicalDevices(instance, &count, nullptr);
    if (result != VK_SUCCESS || count == 0) {
        out << "Vulkan instance created, but no physical GPU was enumerated.\n"
            << "VkResult=" << result << ", device count=" << count;
        vkDestroyInstance(instance, nullptr);
        return env->NewStringUTF(out.str().c_str());
    }

    std::vector<VkPhysicalDevice> devices(count);
    result = vkEnumeratePhysicalDevices(instance, &count, devices.data());
    if (result != VK_SUCCESS) {
        out << "GPU enumeration failed. VkResult=" << result;
        vkDestroyInstance(instance, nullptr);
        return env->NewStringUTF(out.str().c_str());
    }

    out << "Vulkan instance: PASS\n";
    out << "Physical devices found: " << count << "\n\n";
    for (uint32_t i = 0; i < count; ++i) {
        VkPhysicalDeviceProperties props{};
        vkGetPhysicalDeviceProperties(devices[i], &props);
        out << "GPU " << (i + 1) << ": " << props.deviceName << "\n";
        out << "Vulkan API: "
            << VK_VERSION_MAJOR(props.apiVersion) << "."
            << VK_VERSION_MINOR(props.apiVersion) << "."
            << VK_VERSION_PATCH(props.apiVersion) << "\n";
        out << "Vendor ID: 0x" << std::hex << props.vendorID
            << ", Device ID: 0x" << props.deviceID << std::dec << "\n\n";
    }

    out << "RESULT: native Vulkan device discovery passed.\n";
    out << "NEXT: test surface/swapchain rendering, then evaluate port architecture.";
    vkDestroyInstance(instance, nullptr);
    return env->NewStringUTF(out.str().c_str());
}
