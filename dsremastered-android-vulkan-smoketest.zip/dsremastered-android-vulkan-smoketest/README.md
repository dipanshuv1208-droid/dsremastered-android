# Dark Souls Remastered — Android Port Preparation

This is a **small native Android build smoke test**, not a game port. It checks
whether an Android APK can load native C++ code, create a Vulkan instance, and
enumerate the phone's Vulkan physical device(s). It does not draw a frame, load
game files, or run Dark Souls.

## Build without a PC

The included GitHub Actions workflow builds the APK on a hosted Linux runner.
You need a GitHub account and a repository containing these files.

1. Create a new GitHub repository, e.g. `dsremastered-android-vulkan-smoketest`.
2. Upload/extract these project files into the repository root, preserving the
   directory structure.
3. Open the repository's **Actions** tab.
4. If prompted, enable Actions; then run **Build Android Vulkan smoke-test APK**
   using **Run workflow** (or push to `main`).
5. Open the completed workflow run and download the artifact named
   `vulkan-device-check-debug-apk`.
6. Extract the downloaded artifact ZIP; it contains `app-debug.apk`.
7. Transfer/install the APK on your own phone. Android may ask you to allow
   installation from that browser/file manager.
8. Open **Vulkan Device Check** and copy the report or take a screenshot.

## What a pass means

- `Vulkan instance: PASS` and a GPU name mean the native app can use Vulkan's
  instance/device discovery APIs on this phone.
- It does **not** prove swapchain rendering works, that the Lordran Native
  code can be ported, or that the game can reach 20–30 FPS.
- If the build fails, download the workflow log and share it for diagnosis.

## Why this is separate from Lordran Native

The supplied project uses Apple Metal and Apple-specific app integration.
Android would need an Android host and a Vulkan graphics backend, plus further
porting of platform services. This smoke test is a first build milestone, not
the game itself. No game files, keys, or copyrighted assets are included.
